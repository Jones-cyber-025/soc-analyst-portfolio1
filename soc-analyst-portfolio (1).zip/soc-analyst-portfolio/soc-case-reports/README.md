# SOC Alert Investigation Case Reports

Home lab portfolio — alert triage and investigation, written in the format of real SOC
case notes: alert, evidence, investigation steps, findings, verdict, recommendations.

| # | Case | Severity | Category | Verdict |
|---|---|---|---|---|
| 001 | [Suspicious Phishing Email](case-001-phishing-email.md) | Low | Phishing | True Positive |
| 002 | [DNS Exfiltration via PowerShell](case-002-dns-exfiltration-powershell.md) | High | Process / Parent-Child | True Positive |

**Analyst:** Odo Ikenna Jones

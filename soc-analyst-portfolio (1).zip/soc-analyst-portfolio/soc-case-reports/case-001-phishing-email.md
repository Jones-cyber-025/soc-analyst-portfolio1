# Case Report 001 — Suspicious Phishing Email

| | |
|---|---|
| **Analyst** | Odo Ikenna Jones |
| **Date** | 7 July 2026 |
| **Alert ID** | 1000 |
| **Severity** | Low |
| **Category** | Phishing |
| **Status** | Closed — True Positive |

---

## Alert log

![Alert 1000 — suspicious email from external domain](screenshots/case-001-alert-1000.png)

*Figure 1 — Alert #1000: Suspicious email from external domain.*

---

## Summary

An inbound email was flagged for originating from an external sender with an unusual
top-level domain. Investigation confirmed this was a phishing/scam attempt using a classic
advance-fee fraud pattern, requesting the recipient's banking details under the pretense of
an inheritance claim.

---

## Alert details

| Field | Value |
|---|---|
| Datasource | Email |
| Timestamp | 07/07/2026 20:04:59 |
| Subject | "Inheritance Alert: Unknown Billionaire Relative Left You Their Hat Fortunes" |
| Sender | `eileen@trendymillineryco.me` |
| Recipient | `support@tryhatme.com` |
| Attachment | None |
| Direction | Inbound |

---

## Investigation steps

**Step 1 — Sender domain analysis.**
The sender domain (`trendymillineryco.me`) does not match the context of the email content.
A domain suggesting a hat/millinery business sent an email about an unrelated inheritance
claim — a clear mismatch indicating spoofed or disposable scam infrastructure.

**Step 2 — Recipient analysis.**
The recipient (`support@tryhatme.com`) is a generic/shared mailbox, not a named individual.
This indicates the email was likely part of a mass/spray-and-pray campaign rather than
targeted spear-phishing.

**Step 3 — Content analysis.**
The email follows a well-known advance-fee fraud (419 scam) pattern:

- Unexpected windfall (inheritance from an unknown relative)
- Urgency ("claim immediately")
- Direct request for sensitive financial information (banking details)
- No legitimate business or estate communicates this way

**Step 4 — Technical indicator check.**
No attachment and no embedded link were present. This confirms the attack vector is pure
social engineering — the goal is to get the victim to reply directly with personal/financial
information, not to deliver malware.

**Step 5 — Domain reputation check (VirusTotal).**
Checked `trendymillineryco.me` against VirusTotal: 1 out of 92 security vendors (ADMINUSLabs)
flagged the domain as malicious; all others returned clean. This is a weak/inconclusive signal
on its own, since a single flag from a known aggressive vendor doesn't confirm maliciousness.
Combined with the content and domain-context mismatch, however, the overall picture still
supports a phishing verdict.

---

## Findings

- Domain does not align with email content (context mismatch)
- Recipient is a generic mailbox, suggesting mass targeting
- Content matches known advance-fee fraud scam patterns
- No malware payload or credential-harvesting link present — attack relies purely on social engineering
- VirusTotal reputation check was inconclusive alone but supports the overall verdict when combined with other evidence

---

## Verdict

**True Positive** — confirmed phishing/scam attempt (advance-fee fraud). Severity remains Low
due to the absence of malware, attachments, or malicious links.

---

## Recommendations

- Block sender domain `trendymillineryco.me` at the email gateway
- No indication the user replied or submitted information — no further containment required at this time
- Recommend a user awareness reminder regarding inheritance/lottery-style scam emails
- Flag detection rule for tuning: the current rule (unusual TLD) may generate false positives
  against legitimate businesses using less common domains. Consider adding content-based
  indicators (financial request keywords, urgency language) to improve detection accuracy.

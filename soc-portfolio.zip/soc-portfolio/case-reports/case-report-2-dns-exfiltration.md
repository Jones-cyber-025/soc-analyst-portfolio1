# Case Report 2 — DNS Exfiltration via PowerShell

**Analyst:** Odo Ikenna Jones
**Date:** July 7 & 14, 2026
**Alert IDs:** 1034 & 1032 (correlated)
**Severity:** High
**Category:** Process / Suspicious Parent-Child Relationship
**Status:** Closed — True Positive

## Summary
Investigated two "Suspicious Parent-Child Relationship" alerts on host `win-3450` and determined they were part of a single, ongoing DNS exfiltration attack using PowerShell to launch `nslookup.exe` with Base64-encoded data embedded in DNS queries to an external domain. Correlated rather than treated as two separate events, confirming they were stages of the same attack session.

## Investigation Steps

**Step 1 — Classified the alert type.**
Datasource was Sysmon, category Process — applied parent-child process analysis rather than email or network-based logic.

**Step 2 — Checked the child process.**
`nslookup.exe` is a legitimate Windows DNS lookup utility — not malicious alone, but worth scrutinizing given parent process and context.

**Step 3 — Checked the parent process.**
`powershell.exe` spawning `nslookup.exe` is unusual outside scripted admin tasks. The parent PID (3728) was identical across both alerts — confirming one live PowerShell session responsible for both queries, not two unrelated events.

**Step 4 — Checked the working directory.**
Alert 1034 ran from `downloads\`. Alert 1032 ran from `\downloads\exfiltration\`. Legitimate system tools do not run from user Downloads folders; the folder naming itself strongly confirmed intent.

**Step 5 — Analyzed the command line.**
Both alerts queried the same external domain, `haz4rdw4re.io`, with a different Base64-encoded string prepended each time. Decoding the first string produced non-printable/binary output — consistent with fragments of binary data, expected in real DNS exfiltration since data is chunked to fit DNS subdomain length limits.

**Step 6 — Correlated the two alerts.**
Key step: compared alerts directly — same host, same parent PID, same destination domain, new encoded fragment each time — confirming an active, multi-stage exfiltration attempt rather than two coincidental detections.

## Findings
- Same PowerShell process (PID 3728) responsible for both DNS queries
- Same external domain (`haz4rdw4re.io`) used across both alerts, consistent with a single C2/exfiltration channel
- Working directory named "exfiltration" strongly indicates attacker intent
- Base64-encoded subdomains decode to non-printable binary, consistent with fragmented data exfiltration over DNS
- Pattern indicates an active, ongoing attack session rather than an isolated event

## Verdict
**True Positive — High Severity.** Confirmed DNS-based data exfiltration using PowerShell to launch repeated `nslookup` queries carrying encoded data fragments to an external domain.

## Recommendations
- Isolate host `win-3450` immediately to stop further data loss
- Capture and reassemble full DNS query history for this host to recover the complete exfiltrated data stream
- Inspect the user's `Downloads/exfiltration` folder for the source script or file initiating this activity
- Block domain `haz4rdw4re.io` at the DNS/firewall level
- Escalate to the Incident Response team given confirmed active exfiltration

## Key Takeaway
Don't triage alerts in isolation. Checking whether the same PID, host, or domain appeared in a prior alert revealed this wasn't two random detections — it was one continuous attack unfolding in stages. That correlation step is what turns individual alerts into a full attack story.

# Case Report 1 — Suspicious Phishing Email

**Analyst:** Odo Ikenna Jones
**Date:** July 7, 2026
**Alert ID:** 1000
**Severity:** Low
**Category:** Phishing
**Status:** Closed — True Positive

## Summary
An inbound email was flagged for originating from an external sender with an unusual top-level domain. Investigation confirmed this was a phishing/scam attempt using a classic advance-fee fraud pattern, requesting the recipient's banking details under the pretense of an inheritance claim.

## Investigation Steps

**Step 1 — Sender domain analysis**
The sender domain (`trendymillineryco.me`) does not match the context of the email content. A domain suggesting a hat/millinery business sent an email about an unrelated inheritance claim — a clear mismatch indicating spoofed or disposable scam infrastructure.

**Step 2 — Recipient analysis**
The recipient (`support@tryhatme.com`) is a generic/shared mailbox, not a named individual — indicating a mass/spray-and-pray campaign rather than targeted spear-phishing.

**Step 3 — Content analysis**
Follows a well-known advance-fee fraud (419 scam) pattern: unexpected windfall, urgency ("claim immediately"), direct request for banking details. No legitimate business or estate communicates this way.

**Step 4 — Technical indicator check**
No attachment and no embedded link were present, confirming the attack vector is pure social engineering — the goal is a direct reply with financial information, not malware delivery.

**Step 5 — Domain reputation check (VirusTotal)**
`trendymillineryco.me` — 1 of 92 vendors (ADMINUSLabs) flagged as malicious; rest clean. Weak/inconclusive alone, but supports the phishing verdict combined with other evidence.

## Findings
- Domain does not align with email content (context mismatch)
- Recipient is a generic mailbox, suggesting mass targeting
- Content matches known advance-fee fraud scam patterns
- No malware payload or credential-harvesting link — pure social engineering
- VirusTotal check inconclusive alone but supportive overall

## Verdict
**True Positive** — confirmed phishing/scam attempt (advance-fee fraud). Severity remains Low due to absence of malware, attachments, or malicious links.

## Recommendations
- Block sender domain (`trendymillineryco.me`) at the email gateway
- No indication of user reply — no further containment required
- Recommend user awareness reminder regarding inheritance/lottery-style scams
- Flag detection rule for tuning: current rule (unusual TLD) may generate false positives against legitimate businesses using less common domains; consider adding content-based indicators (financial request keywords, urgency language)

# Detection Engineering Report — T1059: Command and Scripting Interpreter (PowerShell)

**MITRE ATT&CK Technique:** T1059.001 — PowerShell
**Tools Used:** Sysmon, Wazuh SIEM, Atomic Red Team
**Environment:** Home lab — Windows 10 endpoint, Wazuh manager
**Author:** Odo Ikenna Jones

## Objective

Detect adversarial use of PowerShell for command execution, a technique heavily abused in real-world intrusions for payload execution, credential theft tooling (e.g., Mimikatz), and living-off-the-land attacks.

## Detection Logic

Built a custom Wazuh rule to flag any process creation event where the process image is `powershell.exe`, based on Sysmon Event ID 1 telemetry.

```xml
<group name="mitre,t1059,execution">
<rule id="100130" level="5">
  <if_group>sysmon_eid1_detections</if_group>
  <field name="win.eventdata.image" type="pcre2">(?i)powershell.exe</field>
  <description>T1059 PowerShell execution detected</description>
  <mitre><id>T1059</id></mitre>
</rule>
</group>
```

## Challenges & Troubleshooting

### 1. Sysmon wasn't logging process creation at all

Initial testing showed zero Event ID 1 hits in Wazuh, despite PowerShell running successfully on the monitored endpoint. Inspecting the live Sysmon configuration confirmed the gap:

```
sysmon64 -c | Select-String -Pattern "ProcessCreate" -Context 0,5
```

No `ProcessCreate` block existed in the active config — Sysmon was only capturing file creation (Event ID 11) and DNS query filtering events. Resolved by deploying a configuration that explicitly enables process creation logging:

```
sysmon64 -c C:\add-processcreate.xml
```

Verified the fix by confirming `data.win.system.eventID: 1` events began appearing in Wazuh Discover.

### 2. Rule group mismatch

After enabling Event ID 1 logging, the custom rule still did not fire. Inspecting a raw Event ID 1 hit in Wazuh Discover revealed the actual decoder-assigned rule group was `sysmon_eid1_detections`, not `sysmon_event1` as initially assumed. Correcting the `<if_group>` value resolved the mismatch and allowed rule 100130 to fire as expected.

## Validation

Used Atomic Red Team to simulate real PowerShell-based execution on the monitored endpoint:

```
Invoke-AtomicTest T1059.001 -TestNumbers 1
```

Confirmed detection by querying Wazuh Discover for `rule.id: 100130`, which returned a match with the following attributes:

| Field | Value |
|---|---|
| rule.id | 100130 |
| rule.groups | mitre, t1059, execution |
| rule.mitre.id | T1059 |
| rule.mitre.tactic | Execution |
| rule.mitre.technique | Command and Scripting Interpreter |

## Key Takeaway

Detection rules are only as good as the telemetry feeding them. A correctly written rule can silently fail if the underlying data source isn't configured to emit the expected events — always verify raw telemetry before assuming a rule's logic is at fault.

## Evidence & Screenshots

**Figure 1 — Wazuh Discover: `rule.id 100130` returning no results (pre-fix)**
Initial query against the custom rule returned no hits, prompting investigation into the telemetry pipeline.

**Figure 2 — Sysmon config missing ProcessCreate logging**
Searching the live Sysmon configuration for a ProcessCreate block returned nothing, confirming Event ID 1 was never being generated.

**Figure 3 — Sysmon configuration updated successfully**
Applying a corrected Sysmon configuration file enabling ProcessCreate logging.

**Figure 4 — Event ID 1 now reaching Wazuh**
After the Sysmon fix, Process Create (Event ID 1) events began appearing in Wazuh.

**Figure 5 — Root cause of rule mismatch identified**
Inspecting a raw Event ID 1 hit revealed the actual rule group was `sysmon_eid1_detections`, not `sysmon_event1` as originally configured.

**Figure 6 — Successful detection: rule 100130 firing**
After correcting the `if_group` value and restarting the Wazuh manager, rule 100130 fired successfully with correct MITRE ATT&CK mapping (T1059, Execution, Command and Scripting Interpreter).

*(Screenshots referenced above are available in the original PDF report; add image files to this folder and link them here if you want them rendered directly on GitHub.)*

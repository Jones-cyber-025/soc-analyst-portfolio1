# Odo Ikenna Jones
**Level 1 SOC Analyst | Detection Engineering | Threat Hunting | Incident Investigation**

🔗 [LinkedIn](https://www.linkedin.com/in/ikenna-odo-2101a6333/)

Level 1 SOC Analyst with hands-on experience across the full detection-to-resolution lifecycle.

- **Detection Engineering** — Built and validated custom Wazuh rules (T1059 PowerShell, T1016 network discovery) using Sysmon + MITRE ATT&CK. Diagnosed and fixed a real Sysmon telemetry failure that was silently blocking detection.
- **Alert Triage** — Investigated and closed real-style cases: a phishing/advance-fee-fraud email and a high-severity DNS exfiltration incident, correlating two alerts by PID, host, and domain to reveal one ongoing attack.
- **Tools** — Wazuh, Sysmon, Atomic Red Team, VirusTotal, MITRE ATT&CK.
- **Communication** — Every case documented with clear findings, evidence, and recommendations.

Currently expanding into phishing simulation, malware analysis, and network security, building toward a full incident response playbook.

Open to connecting with SOC analysts, hiring managers, and detection engineers.

---

## About This Repository

This repository documents hands-on work from a home-built Security Operations Center (SOC) lab, covering detection engineering, alert triage, and threat hunting. Everything here was built and tested in a real environment: a Wazuh SIEM manager, a Windows 10 endpoint running Sysmon, and validated using industry-standard adversary simulation tooling (Atomic Red Team).

The goal of this portfolio is to demonstrate practical, end-to-end SOC analyst skills — not just theoretical knowledge — including detection rule authoring, root-cause troubleshooting of telemetry pipelines, alert investigation, and correlation across multiple alerts into a single attack narrative.

## Lab Environment

| Component | Details |
|---|---|
| SIEM | Wazuh Manager |
| Endpoint | Windows 10 (Sysmon-instrumented) |
| Telemetry | Sysmon Event IDs (Process Create, Process Access, DNS Query, etc.) |
| Validation Tooling | Atomic Red Team |
| Frameworks | MITRE ATT&CK |

## Contents

### Detection Rules
- [T1059 — PowerShell Execution Detection](./detection-rules/T1059-powershell/writeup.md) — Custom Wazuh rule detecting adversarial PowerShell execution via Sysmon Event ID 1, including full root-cause troubleshooting of a broken telemetry pipeline.

### Case Reports (Alert Triage & Investigation)
- [Case Report 1 — Suspicious Phishing Email](./case-reports/case-report-1-phishing-email.md) — Triage of an advance-fee fraud phishing email, including domain reputation analysis and verdict reasoning.
- [Case Report 2 — DNS Exfiltration via PowerShell](./case-reports/case-report-2-dns-exfiltration.md) — Correlated investigation of two related alerts revealing an active DNS-based data exfiltration session.

## Key Skills Demonstrated

- Writing and validating custom SIEM detection rules mapped to MITRE ATT&CK
- Diagnosing and fixing broken telemetry pipelines (Sysmon configuration troubleshooting)
- Alert triage and evidence-based verdict reasoning
- Correlating multiple alerts into a single attack timeline rather than triaging in isolation
- Using reputation/threat-intel tools (VirusTotal) to support investigative conclusions
- Adversary simulation and detection validation using Atomic Red Team

---

*This portfolio is actively growing — upcoming additions include a simulated phishing attack lab, malware analysis, network security projects, and a full incident response playbook.*
